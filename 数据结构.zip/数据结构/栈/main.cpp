#include "stack.h"
#include <fstream>
int main()
{
    stack* s = initstack();
    // 文件输入
    ifstream in("data.txt");
    if(!in)
    {
        cout<<"Failed to open file!"<<endl;
        return 1;
    }
    char ch;

    while(in>>ch)
        push(s,ch);

    in.close();
    Traverse(s);
    destroy(s);
    return 0;
}