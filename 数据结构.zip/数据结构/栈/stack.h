#pragma once
#include <iostream>
using namespace std;

typedef char elemtype;
typedef struct stack{
    elemtype data;
    stack* next;
}stack;

stack* initstack();

void push(stack* s, elemtype e);

elemtype pop(stack* s);

elemtype GetTop(stack* s);

void Traverse(stack* s);

void clear(stack* s);

void destroy(stack* s);

bool isEmpty(stack* s);


