#include "stack.h"
stack* initstack()
{
    stack* s = new stack;
    s->next = NULL;
    return s;
}

void push(stack* s, elemtype e)
{
    stack* p = new stack;
    p->data = e;
    p->next = s->next;
    s->next = p;
}

elemtype pop(stack* s)
{
    stack* p = s->next;
    elemtype e = p->data;
    s->next = p->next;
    delete p;
    return e;
}

elemtype GetTop(stack* s)
{
    if(s->next==nullptr)
    {
        cout<<"stack is empty"<<endl;
        return '\0';
    }
    return s->next->data;
}

void Traverse(stack* s)
{
    if(s->next==nullptr)
    {
        cout<<"stack is empty"<<endl;
        return;
    }
    stack* dummy=s->next;
    while(dummy!=nullptr)
    {
        cout<<dummy->data<<" ";
        dummy=dummy->next;
    }
}

void clear(stack* s)
{
    if(s->next==nullptr)
    {
        cout<<"stack is empty"<<endl;
        return;
    }
    stack* dummy=s->next;
    while(dummy!=nullptr)
    {
        stack* p=dummy;
        dummy=dummy->next;
        delete p;
    }
    s->next=nullptr;
}

void destroy(stack* s)
{
    clear(s);
    delete s;
}

bool isEmpty(stack* s)
{
    return s->next==nullptr;
}