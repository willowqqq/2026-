# SQL 基础复习指南(MySQL 8.0)

> 配套练习数据库:**`sql_practice`**(教师/课程/学生/成绩 4 张表,197 条成绩数据)
> 初始化脚本:与本文件同目录的 `sql_practice.sql`。练习中把数据改乱了,重新执行该脚本即可一键重置:
>
> ```bash
> mysql -u root -p --default-character-set=utf8mb4 < sql_practice.sql
> ```
>
> 建议每天按阶段推进,每个阶段先看知识点和示例,再完成"动手练习"。全部完成后做最后的 20 道综合题自测。

---

## 0. 环境准备与数据库说明

### 0.1 连接数据库

```bash
mysql -u root -p          # 回车后输入密码(交互输入,避免密码出现在命令行)
```

```sql
SHOW DATABASES;           -- 查看所有数据库
USE sql_practice;         -- 切换到练习库(之后每条语句都作用于该库)
SELECT DATABASE();        -- 确认当前所在库
SHOW TABLES;              -- 查看库中所有表
DESC students;            -- 查看某张表的结构
SHOW CREATE TABLE scores; -- 查看建表语句(含索引、外键)
```

### 0.2 表结构与关系

```
┌──────────┐ 1:n  ┌──────────┐ 1:n  ┌──────────┐ n:1  ┌──────────┐
│ teachers │──────│ courses  │──────│  scores  │──────│ students │
└──────────┘      └──────────┘      └──────────┘      └──────────┘
  教师表            课程表            成绩表             学生表
```

| 表 | 字段 | 说明 |
|---|---|---|
| `teachers` 教师表 | `teacher_id` 主键、`name` 姓名、`title` 职称、`hire_date` 入职日期 | 8 名教师 |
| `courses` 课程表 | `course_id` 主键、`course_name` 课程名、`credits` 学分、`teacher_id` 外键→教师 | 9 门课程 |
| `students` 学生表 | `student_id` 主键、`name`、`gender`、`birth_date`、`major` 专业、`class_name` 班级 | 30 名学生 |
| `scores` 成绩表 | 联合主键 (`student_id`, `course_id`)、`score` 成绩、`exam_date` 考试日期 | 197 条记录 |

### 0.3 数据特点(刻意设计的"坑",练习时会遇到)

- 学生分布:计科 1/2 班、软工 1 班、人工智能 1 班,共 3 个专业
- **"离散数学"无人选修**、**吴敏老师没开课** → 练 LEFT JOIN 找"没有……"的场景
- 成绩中有 **6 条缺考(score 为 NULL)**、19 条不及格(<60)→ 练 NULL 处理和 HAVING
- 赵敏只选 2 门课、林悦选满 8 门课;张伟老师教 2 门课(数据结构、数据库原理)→ 练"选修某老师全部课程"这类题
- 存在并列最高分 → 练并列排名问题

---

## 1. DDL:数据定义语言(建表/改表/删表)

### 知识点

| 常用数据类型 | 说明 | 示例 |
|---|---|---|
| `INT` | 整数 | `student_id` |
| `DECIMAL(M,D)` | 定点小数,精确 | `credits DECIMAL(3,1)` |
| `VARCHAR(N)` | 变长字符串 | `name VARCHAR(20)` |
| `DATE` / `DATETIME` | 日期 / 日期时间 | `birth_date` |
| `TEXT` | 长文本 | |

| 约束 | 说明 |
|---|---|
| `PRIMARY KEY` | 主键:非空且唯一,一张表只有一个 |
| `FOREIGN KEY ... REFERENCES` | 外键:保证引用完整性 |
| `UNIQUE` | 唯一(可为 NULL,MySQL 允许多个 NULL) |
| `NOT NULL` / `DEFAULT` | 非空 / 默认值 |
| `AUTO_INCREMENT` | 自增(通常用于主键) |

### 示例

```sql
-- 建一张练习用的临时表
CREATE TABLE practice_log (
    id         INT AUTO_INCREMENT PRIMARY KEY,
    note       VARCHAR(100) NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- 修改表:加列 / 改列 / 删列
ALTER TABLE practice_log ADD COLUMN tag VARCHAR(20);
ALTER TABLE practice_log MODIFY COLUMN tag VARCHAR(30);
ALTER TABLE practice_log DROP COLUMN tag;

-- 删除表
DROP TABLE practice_log;
```

### 动手练习

1. 建一张 `book` 表:编号(自增主键)、书名(非空)、价格 `DECIMAL(6,2)`、出版日期。
2. 给 `book` 表增加"出版社"列,再把价格列改成 `DECIMAL(8,2)`,最后删掉整个表。

<details>
<summary>参考答案</summary>

```sql
CREATE TABLE book (
    book_id    INT AUTO_INCREMENT PRIMARY KEY,
    book_name  VARCHAR(50) NOT NULL,
    price      DECIMAL(6,2),
    pub_date   DATE
);
ALTER TABLE book ADD COLUMN publisher VARCHAR(50);
ALTER TABLE book MODIFY COLUMN price DECIMAL(8,2);
DROP TABLE book;
```
</details>

---

## 2. DML:数据操作语言(增/删/改)

### 知识点与示例

```sql
-- INSERT:单行 / 多行
INSERT INTO students (name, gender, birth_date, major, class_name)
VALUES ('测试学生', '男', '2005-01-01', '计算机科学与技术', '计科1班');

INSERT INTO students (name, gender) VALUES
('测试A', '男'), ('测试B', '女');

-- UPDATE:⚠️ 不写 WHERE 会更新整张表!
UPDATE students SET class_name = '计科3班' WHERE name = '测试学生';

-- DELETE:⚠️ 同理,先写 WHERE;删错了在事务里还能回滚(见第 10 阶段)
DELETE FROM students WHERE name IN ('测试学生', '测试A', '测试B');
```

> **TRUNCATE vs DELETE**:`TRUNCATE TABLE` 清空整表,速度快、**不可回滚**、自增计数重置;`DELETE` 逐行删除、可回滚、自增不重置。

### 动手练习

1. 插入一条学生记录(用你喜欢的名字),再把它改个班级,最后删掉。
2. 把学生"赵敏"的选课补上一门:插入 `scores` 记录(`course_id=4`, 成绩 88, 考试日期 `2025-06-01`),**插入后用 SELECT 确认,再删除这条记录**(保持原数据干净)。

<details>
<summary>参考答案</summary>

```sql
-- 练习1
INSERT INTO students (name, gender, major, class_name) VALUES ('张三', '男', '软件工程', '软工1班');
UPDATE students SET class_name = '软工2班' WHERE name = '张三';
DELETE FROM students WHERE name = '张三';

-- 练习2
INSERT INTO scores (student_id, course_id, score, exam_date) VALUES (5, 4, 88, '2025-06-01');
SELECT * FROM scores WHERE student_id = 5;          -- 确认插入成功
DELETE FROM scores WHERE student_id = 5 AND course_id = 4;  -- 恢复原状
```
</details>

---

## 3. 单表查询(核心中的核心)

### 知识点

**SELECT 子句的书写顺序 vs 执行顺序**(必背):

```sql
SELECT 列            -- 5. 选出要显示的列(别名在此可用)
FROM 表              -- 1. 先找表
WHERE 条件           -- 2. 过滤行
GROUP BY 分组列      -- 3. 分组
HAVING 分组后条件    -- 4. 过滤组
ORDER BY 排序列      -- 6. 排序
LIMIT 数量;          -- 7. 取前 N 行
```

**WHERE 常用运算符**:

| 运算符 | 含义 | 示例 |
|---|---|---|
| `=` `<>`(或`!=`) `>` `<` `>=` `<=` | 比较 | `credits >= 3` |
| `AND` / `OR` / `NOT` | 逻辑(AND 优先级高于 OR,拿不准就加括号) | `major='人工智能' AND gender='女'` |
| `IN (...)` | 匹配多个值 | `major IN ('软件工程','人工智能')` |
| `BETWEEN a AND b` | 闭区间 [a,b] | `birth_date BETWEEN '2004-01-01' AND '2005-12-31'` |
| `LIKE` | 模糊匹配,`%` 任意多字符、`_` 单个字符 | `name LIKE '王%'` |
| `IS NULL` / `IS NOT NULL` | 判空 | `score IS NULL` |

> **NULL 的三值逻辑**:任何值与 NULL 比较结果都是 NULL(既非真也非假),所以 `score = NULL` 永远查不到东西,必须用 `IS NULL`;`NOT (score >= 60)` 也排除不了 NULL 行,正确写法是 `score < 60 OR score IS NULL`。

### 示例

```sql
SELECT name, major, class_name FROM students WHERE major = '软件工程';

SELECT name FROM students WHERE name LIKE '王%';   -- 王浩、王强
SELECT name FROM students WHERE name LIKE '王_';   -- 单字名,本库查不到

SELECT * FROM scores WHERE score IS NULL;          -- 缺考记录(6 条)

SELECT DISTINCT major FROM students;               -- 去重:3 个专业
```

### 动手练习

1. 查出所有 2005 年及以后出生的学生姓名和出生日期。
2. 查出人工智能专业的所有女生。
3. 查出"数据库原理"课程编号、学分和授课教师编号(先看 `DESC courses` 再写)。
4. 查出成绩不及格或缺考的所有成绩记录,数一数共几条。

<details>
<summary>参考答案</summary>

```sql
SELECT name, birth_date FROM students WHERE birth_date >= '2005-01-01';

SELECT name FROM students WHERE major = '人工智能' AND gender = '女';

SELECT course_id, credits, teacher_id FROM courses WHERE course_name = '数据库原理';

SELECT * FROM scores WHERE score < 60 OR score IS NULL;  -- 共 25 条
```
</details>

---

## 4. 排序与分页

### 知识点与示例

```sql
-- 多列排序:先按学分降序,学分相同按课程编号升序
SELECT course_name, credits FROM courses
ORDER BY credits DESC, course_id ASC;

-- LIMIT 取前 N 行;OFFSET 跳过前 M 行(LIMIT 数量 OFFSET 偏移,偏移从 0 开始)
SELECT name, birth_date FROM students ORDER BY birth_date LIMIT 5;           -- 前 5
SELECT name, birth_date FROM students ORDER BY birth_date LIMIT 5 OFFSET 10; -- 第 11~15

-- 经典题:某门课的第二高分(LIMIT 1 OFFSET 1)
SELECT student_id, score FROM scores
WHERE course_id = 1 AND score IS NOT NULL
ORDER BY score DESC LIMIT 1 OFFSET 1;
```

> 注意:ORDER BY 默认升序 ASC;NULL 在排序时视为最小值(升序时排最前)。并列名次的精确处理需要窗口函数(第 11 阶段)。

### 动手练习

1. 按出生日期从晚到早列出所有学生,只显示前 8 名。
2. 查出学分第 2 高的课程名和学分。

<details>
<summary>参考答案</summary>

```sql
SELECT name, birth_date FROM students ORDER BY birth_date DESC LIMIT 8;

SELECT course_name, credits FROM courses ORDER BY credits DESC LIMIT 1 OFFSET 1; -- 数据结构 4.0
```
</details>

---

## 5. 聚合与分组

### 知识点

| 聚合函数 | 说明 |
|---|---|
| `COUNT(*)` | 数行数(含 NULL 行) |
| `COUNT(列)` | 数该列**非 NULL** 值的个数 |
| `SUM` / `AVG` | 求和 / 平均(**忽略 NULL**) |
| `MAX` / `MIN` | 最大 / 最小(忽略 NULL) |
| `GROUP_CONCAT(列)` | 把组内该列值拼成一个字符串 |

**GROUP BY 规则**:SELECT 里出现的非聚合列,必须出现在 GROUP BY 中。

**WHERE vs HAVING**:WHERE 在分组**前**过滤行(不能用聚合函数);HAVING 在分组**后**过滤组(必须用聚合函数)。SQL 执行顺序:WHERE → GROUP BY → HAVING。

### 示例

```sql
-- 每个专业多少人,按人数降序
SELECT major, COUNT(*) AS cnt FROM students
GROUP BY major ORDER BY cnt DESC;

-- 每门课的平均分,只看平均分 ≥ 75 的,按平均分降序
SELECT course_id, ROUND(AVG(score), 1) AS avg_s
FROM scores
GROUP BY course_id
HAVING AVG(score) >= 75
ORDER BY avg_s DESC;

-- 每个学生的选课列表拼起来
SELECT student_id, GROUP_CONCAT(course_id ORDER BY course_id) AS courses
FROM scores GROUP BY student_id;
```

### 动手练习

1. 统计男生、女生各多少人。
2. 查每门课的选课人数、最高分、最低分,按选课人数降序。
3. 找出有缺考记录的学生人数(注意去重:一个学生可能多门缺考)。
4. 查平均分低于 75 的学生姓名和平均分。

<details>
<summary>参考答案</summary>

```sql
SELECT gender, COUNT(*) FROM students GROUP BY gender;

SELECT course_id, COUNT(*) AS cnt, MAX(score), MIN(score)
FROM scores GROUP BY course_id ORDER BY cnt DESC;

SELECT COUNT(DISTINCT student_id) FROM scores WHERE score IS NULL;  -- 6 人

SELECT s.name, ROUND(AVG(sc.score),1) AS avg_score
FROM students s JOIN scores sc ON s.student_id = sc.student_id
GROUP BY s.student_id, s.name
HAVING AVG(sc.score) < 75;
```
</details>

---

## 6. 多表连接

### 知识点

语法:`表A [INNER|LEFT|RIGHT] JOIN 表B ON 连接条件`;ON 后接连接条件,WHERE 放过滤条件(逻辑上等价,但分开写更清晰)。

| 连接类型 | 结果 |
|---|---|
| `INNER JOIN`(内连接) | 两表都满足条件的行(交集) |
| `LEFT JOIN`(左连接) | 左表全部保留,右表无匹配的填 NULL ← **"找出没有……"类题首选** |
| `RIGHT JOIN`(右连接) | 右表全部保留,左表无匹配填 NULL(可用 LEFT 替代,少用) |
| `CROSS JOIN`(交叉连接) | 笛卡尔积,所有组合 |

多列同名时可用 `USING(列名)` 代替 `ON a.列 = b.列`。

### 示例

```sql
-- 三表连接:学生姓名 + 课程名 + 成绩
SELECT s.name, c.course_name, sc.score
FROM scores sc
JOIN students s ON sc.student_id = s.student_id
JOIN courses c  ON sc.course_id  = c.course_id
WHERE s.name = '赵敏';

-- 没人选修的课程(左连接 + IS NULL)
SELECT c.course_name
FROM courses c
LEFT JOIN scores sc ON c.course_id = sc.course_id
WHERE sc.course_id IS NULL;                    -- 离散数学

-- 没开课的教师
SELECT t.name
FROM teachers t
LEFT JOIN courses c ON t.teacher_id = c.teacher_id
WHERE c.course_id IS NULL;                     -- 吴敏

-- 自连接:找出与"陈宇"同班的所有人
SELECT s2.name
FROM students s1
JOIN students s2 ON s1.class_name = s2.class_name
WHERE s1.name = '陈宇' AND s2.name <> '陈宇';
```

### 动手练习

1. 查"数据结构"这门课所有学生的姓名和成绩,按成绩降序。
2. 查每个教师的姓名及其教的课程名(含没开课的教师)。
3. 查每门课的选课人数(含 0 人的课)。

<details>
<summary>参考答案</summary>

```sql
SELECT s.name, sc.score
FROM scores sc
JOIN students s ON sc.student_id = s.student_id
JOIN courses c  ON sc.course_id  = c.course_id
WHERE c.course_name = '数据结构'
ORDER BY sc.score DESC;

SELECT t.name, c.course_name
FROM teachers t LEFT JOIN courses c ON t.teacher_id = c.teacher_id;

SELECT c.course_name, COUNT(sc.student_id) AS cnt
FROM courses c LEFT JOIN scores sc ON c.course_id = sc.course_id
GROUP BY c.course_id, c.course_name ORDER BY cnt DESC;
```
</details>

---

## 7. 子查询

### 知识点

按返回结果分:

| 类型 | 返回 | 常用位置 | 运算符 |
|---|---|---|---|
| 标量子查询 | 单行单列 | WHERE / SELECT | `=` `>` `<` |
| 列子查询 | 多行单列 | WHERE | `IN` `ANY` `ALL` |
| 表子查询(派生表) | 多行多列 | FROM | 起别名后当表用 |

按是否引用外层分:**非相关子查询**(独立执行一次)与**相关子查询**(引用外层,外层每行都执行一次,如 EXISTS)。

`EXISTS(子查询)`:只要子查询**能查到至少一行**就返回真,常用于相关子查询;数据量大时通常比 IN 效率高(找到即停)。

### 示例

```sql
-- 标量子查询:选了"数据结构"的学生姓名
SELECT name FROM students WHERE student_id IN (
    SELECT student_id FROM scores
    WHERE course_id = (SELECT course_id FROM courses WHERE course_name = '数据结构')
);

-- ANY:成绩超过"数据库原理"任一成绩的学生(等价于超过最低分)
SELECT DISTINCT s.name FROM students s JOIN scores sc ON s.student_id = sc.student_id
WHERE sc.score > ANY (
    SELECT score FROM scores sc2 JOIN courses c ON sc2.course_id = c.course_id
    WHERE c.course_name = '数据库原理'
);

-- EXISTS(相关子查询):选了"数据结构"的学生
SELECT s.name FROM students s
WHERE EXISTS (
    SELECT 1 FROM scores sc
    JOIN courses c ON sc.course_id = c.course_id
    WHERE sc.student_id = s.student_id AND c.course_name = '数据结构'
);
```

### 动手练习

1. 查出高于全库平均分的成绩记录(数量、字段自定)。
2. 用 EXISTS 改写:查选了"大学英语"且成绩 ≥ 90 的学生姓名。

<details>
<summary>参考答案</summary>

```sql
SELECT COUNT(*) FROM scores WHERE score > (SELECT AVG(score) FROM scores);

SELECT s.name FROM students s
WHERE EXISTS (
    SELECT 1 FROM scores sc
    JOIN courses c ON sc.course_id = c.course_id
    WHERE sc.student_id = s.student_id
      AND c.course_name = '大学英语' AND sc.score >= 90
);
```
</details>

---

## 8. 常用函数

### 字符串函数

| 函数 | 说明 | 示例 |
|---|---|---|
| `CONCAT(a, b, ...)` / `CONCAT_WS('分隔符', ...)` | 拼接 | `CONCAT(major, '-', class_name)` |
| `LEFT(s,n)` / `RIGHT(s,n)` / `SUBSTRING(s, 起, 长)` | 截取(位置从 1 开始) | `SUBSTRING(name,1,1)` 取姓 |
| `REPLACE(s, a, b)` / `TRIM(s)` | 替换 / 去首尾空格 | `REPLACE(course_name,'原理','')` |
| `UPPER` / `LOWER` | 大小写 | |
| `CHAR_LENGTH(s)` | 字符数(中文算 1 个;`LENGTH` 算字节数,中文 3 字节) | |

### 数值函数:`ROUND(x,d)` 四舍五入保留 d 位、`CEIL` 向上取整、`FLOOR` 向下取整、`ABS`、`MOD(x,y)`(或 `x % y`)。

### 日期函数

| 函数 | 说明 | 示例 |
|---|---|---|
| `NOW()` / `CURDATE()` | 当前日期时间 / 当前日期 | |
| `DATE_FORMAT(d, '格式')` | 格式化 | `'%Y年%m月%d日'` |
| `DATEDIFF(a, b)` | a - b 的天数 | |
| `TIMESTAMPDIFF(单位, a, b)` | b - a 的差值,单位 YEAR/MONTH/DAY/HOUR... | 算年龄见下 |
| `YEAR(d)` / `MONTH(d)` / `DAY(d)` | 取年月日 | |

### 条件函数

```sql
IF(条件, 值1, 值2)                          -- 三目
CASE WHEN 条件 THEN 值 ... ELSE 值 END       -- 多分支
IFNULL(x, 默认值) / COALESCE(a, b, ...)      -- NULL 兜底,COALESCE 返回第一个非 NULL
```

### 示例

```sql
-- 算年龄
SELECT name, TIMESTAMPDIFF(YEAR, birth_date, CURDATE()) AS age
FROM students LIMIT 5;

-- 成绩分等级(缺考单独处理)
SELECT student_id, course_id,
       CASE WHEN score IS NULL THEN '缺考'
            WHEN score >= 90    THEN '优秀'
            WHEN score >= 80    THEN '良好'
            WHEN score >= 60    THEN '及格'
            ELSE '不及格' END AS grade
FROM scores LIMIT 10;

-- 把缺考按 0 分参与统计
SELECT AVG(IFNULL(score, 0)) FROM scores;
```

### 动手练习

1. 查所有学生的姓名和一个叫 `姓名-班级` 的拼接列。
2. 查出每门课最近一次考试的日期,格式化为 `YYYY年MM月DD日`。

<details>
<summary>参考答案</summary>

```sql
SELECT name, CONCAT(name, '-', class_name) AS info FROM students;

SELECT c.course_name, DATE_FORMAT(MAX(sc.exam_date), '%Y年%m月%d日') AS last_exam
FROM scores sc JOIN courses c ON sc.course_id = c.course_id
GROUP BY sc.course_id, c.course_name;
```
</details>

---

## 9. 视图与索引

### 视图(虚拟表)

```sql
-- 创建:学生成绩汇总视图(省得每次写三表连接)
CREATE OR REPLACE VIEW v_student_scores AS
SELECT s.student_id, s.name, c.course_name, sc.score
FROM scores sc
JOIN students s ON sc.student_id = s.student_id
JOIN courses c  ON sc.course_id  = c.course_id;

SELECT * FROM v_student_scores WHERE name = '赵敏';   -- 当普通表用
DROP VIEW v_student_scores;
```

> 视图不存数据,只存查询语句;简单视图(单表、含主键)可以增删改并影响基表,多表连接视图一般不可更新。

### 索引

| 类型 | 说明 |
|---|---|
| 主键索引 | 建表时随 `PRIMARY KEY` 自动创建 |
| 唯一索引 | `UNIQUE KEY` 或 `CREATE UNIQUE INDEX` |
| 普通索引 | `CREATE INDEX` 或建表时 `KEY` |
| 复合索引 | 多列组成的索引,注意**最左前缀**原则 |

```sql
SHOW INDEX FROM courses;                       -- 看现有索引(PK、uk_course_name、idx_teacher)
CREATE INDEX idx_score_course ON scores(course_id);   -- 给成绩表的课程列建索引
EXPLAIN SELECT * FROM scores WHERE course_id = 4;     -- 看执行计划(type/key 列)
DROP INDEX idx_score_course ON scores;
```

> 建索引原则:高频出现在 WHERE / JOIN / ORDER BY 的列;区分度高的列(性别这种只有两种值的列建了也白建);更新频繁的列少建;索引不是越多越好(拖慢写入、占空间)。

### 动手练习

1. 创建一个视图,包含:课程名、学分、教师姓名。
2. 用 EXPLAIN 对比:按姓名查学生(`name` 已有索引)和按班级查学生(`class_name` 无索引),观察 `type` 和 `rows` 的差异。

<details>
<summary>参考答案</summary>

```sql
CREATE VIEW v_course_teacher AS
SELECT c.course_name, c.credits, t.name AS teacher_name
FROM courses c JOIN teachers t ON c.teacher_id = t.teacher_id;

EXPLAIN SELECT * FROM students WHERE name = '王浩';
EXPLAIN SELECT * FROM students WHERE class_name = '计科1班';
```
</details>

---

## 10. 事务

### 知识点

**ACID**:原子性(Atomicity,要么全做要么全不做)、一致性(Consistency)、隔离性(Isolation)、持久性(Durability)。

MySQL 默认每条语句自动提交(`autocommit=1`);`START TRANSACTION` 之后必须显式 `COMMIT` 或 `ROLLBACK`。

```sql
-- 模拟"给赵敏补一门课"再反悔
START TRANSACTION;
INSERT INTO scores (student_id, course_id, score, exam_date) VALUES (5, 4, 88, '2025-06-01');
SELECT * FROM scores WHERE student_id = 5;    -- 本事务内能看到新数据
ROLLBACK;                                      -- 撤销
SELECT * FROM scores WHERE student_id = 5;    -- 又只剩 2 门课

-- 保存点:部分回滚
START TRANSACTION;
INSERT INTO scores VALUES (5, 4, 88, '2025-06-01');
SAVEPOINT sp1;
INSERT INTO scores VALUES (5, 5, 90, '2025-06-01');
ROLLBACK TO sp1;                               -- 撤销第二条插入
COMMIT;                                        -- 提交第一条
DELETE FROM scores WHERE student_id = 5 AND course_id = 4;  -- 清理练习数据
```

隔离级别(默认 **REPEATABLE READ**):

| 隔离级别 | 脏读 | 不可重复读 | 幻读 |
|---|---|---|---|
| READ UNCOMMITTED | ✓ | ✓ | ✓ |
| READ COMMITTED | ✗ | ✓ | ✓ |
| REPEATABLE READ | ✗ | ✗ | ✓(InnoDB 大部分防住) |
| SERIALIZABLE | ✗ | ✗ | ✗ |

```sql
SELECT @@transaction_isolation;                     -- 查看当前隔离级别
SET SESSION TRANSACTION ISOLATION LEVEL READ COMMITTED;  -- 修改
```

### 动手练习

1. 开启事务,更新学生"赵敏"的专业为"软件工程",SELECT 确认后 `ROLLBACK`,再确认已还原。
2. 开启事务,删除一条成绩并 `COMMIT`,再把它插回去(注意用练习 1 学到的 INSERT 语法)。

<details>
<summary>参考答案</summary>

```sql
START TRANSACTION;
UPDATE students SET major = '软件工程' WHERE name = '赵敏';
SELECT name, major FROM students WHERE name = '赵敏';
ROLLBACK;
SELECT name, major FROM students WHERE name = '赵敏';   -- 仍是 计算机科学与技术

-- 删除前先看一眼要删的值,方便之后恢复
SELECT * FROM scores WHERE student_id = 5;   -- 高等数学 59.0 / 大学英语 66.0
START TRANSACTION;
DELETE FROM scores WHERE student_id = 5 AND course_id = 1;
COMMIT;
-- 把刚才删的记录原样插回去
INSERT INTO scores (student_id, course_id, score, exam_date) VALUES (5, 1, 59.0, '2025-01-06');
```
</details>

---

## 11. 窗口函数(MySQL 8.0)

### 知识点

语法:`函数() OVER (PARTITION BY 分组列 ORDER BY 排序列)`,与 GROUP BY 不同:**保留每一行明细**,适合排名、累计等"行内"计算。

| 排名函数 | 并列处理 | 结果示例 |
|---|---|---|
| `ROW_NUMBER()` | 不并列,强行编号 | 1,2,3,4 |
| `RANK()` | 并列同名次,**跳号** | 1,2,2,4 |
| `DENSE_RANK()` | 并列同名次,**不跳号** | 1,2,2,3 |

聚合函数也可开窗:`SUM/AVG/COUNT(...) OVER (...)`。

### 示例

```sql
-- 高等数学的排名(观察并列)
SELECT s.name, sc.score,
       RANK() OVER (ORDER BY sc.score DESC) AS rk,
       DENSE_RANK() OVER (ORDER BY sc.score DESC) AS drk
FROM scores sc JOIN students s ON sc.student_id = s.student_id
WHERE sc.course_id = 1 AND sc.score IS NOT NULL
ORDER BY sc.score DESC;

-- 每门课的前 3 名(子查询 + DENSE_RANK)
SELECT * FROM (
    SELECT sc.course_id, s.name, sc.score,
           DENSE_RANK() OVER (PARTITION BY sc.course_id ORDER BY sc.score DESC) AS rk
    FROM scores sc JOIN students s ON sc.student_id = s.student_id
    WHERE sc.score IS NOT NULL
) t WHERE rk <= 3;
```

### 动手练习

1. 用 ROW_NUMBER 给每个学生按总分排名(并列时随便先后)。
2. 用窗口函数查每门课的最低分学生。

<details>
<summary>参考答案</summary>

```sql
SELECT s.name, SUM(sc.score) AS total,
       ROW_NUMBER() OVER (ORDER BY SUM(sc.score) DESC) AS rn
FROM students s JOIN scores sc ON s.student_id = sc.student_id
WHERE sc.score IS NOT NULL
GROUP BY s.student_id, s.name;

SELECT course_id, name, score FROM (
    SELECT sc.course_id, s.name, sc.score,
           RANK() OVER (PARTITION BY sc.course_id ORDER BY sc.score ASC) AS rk
    FROM scores sc JOIN students s ON sc.student_id = s.student_id
    WHERE sc.score IS NOT NULL
) t WHERE rk = 1;
```
</details>

---

## 12. 综合练习(20 题,由易到难)

> 先独立完成,再对照文末答案。每题都基于 `sql_practice` 库。

1. 查询所有学生的学号、姓名、专业、班级。
2. 查询 2005 年及以后出生的学生姓名和出生日期。
3. 查询所有姓"王"的学生。
4. 查询每门课程的名称和学分,按学分从高到低排序。
5. 统计每个专业的学生人数,按人数降序。
6. 查询每个学生的选课门数和平均分(保留 1 位小数),包括没选课的学生。
7. 查询平均分低于 75 的学生姓名和平均分。
8. 查询每门课的平均分、最高分、最低分,只保留平均分 > 70 的课,按平均分降序。
9. 查询"高等数学"最高分学生的姓名和分数。
10. 查询没有任何学生选修的课程。
11. 查询没有开任何课程的教师。
12. 查询选了 5 门以上课程的学生姓名和选课门数。
13. 查询有缺考记录的学生名单(去重)。
14. 查询每门课程的选课人数(含 0 人的课),按人数降序。
15. 查询每门课成绩最高的学生(相关子查询;注意并列)。
16. 查询"数据库原理"成绩高于该课平均分的学生姓名和成绩。
17. 查询选修了**张伟老师全部课程**的学生姓名。
18. 查询所有成绩都及格(≥60,且无缺考)的学生姓名。
19. 按学生总分排名(并列同名次,用 RANK),显示前 5 名。
20. 查询年龄最大的 5 名学生。

### 参考答案

<details>
<summary>点击展开全部答案</summary>

```sql
-- 1
SELECT student_id, name, major, class_name FROM students;

-- 2
SELECT name, birth_date FROM students WHERE birth_date >= '2005-01-01';

-- 3
SELECT name FROM students WHERE name LIKE '王%';        -- 王浩、王强

-- 4
SELECT course_name, credits FROM courses ORDER BY credits DESC, course_id;

-- 5
SELECT major, COUNT(*) AS cnt FROM students GROUP BY major ORDER BY cnt DESC;

-- 6
SELECT s.student_id, s.name, COUNT(sc.course_id) AS course_cnt,
       ROUND(AVG(sc.score), 1) AS avg_score
FROM students s LEFT JOIN scores sc ON s.student_id = sc.student_id
GROUP BY s.student_id, s.name ORDER BY s.student_id;

-- 7
SELECT s.name, ROUND(AVG(sc.score), 1) AS avg_score
FROM students s JOIN scores sc ON s.student_id = sc.student_id
GROUP BY s.student_id, s.name HAVING AVG(sc.score) < 75;

-- 8
SELECT course_id, ROUND(AVG(score),1) AS avg_s, MAX(score) AS max_s, MIN(score) AS min_s
FROM scores GROUP BY course_id HAVING AVG(score) > 70 ORDER BY avg_s DESC;

-- 9 (相关子查询;并列时返回多行,只想取一行可再加 LIMIT 1)
SELECT s.name, sc.score
FROM scores sc JOIN students s USING(student_id) JOIN courses c USING(course_id)
WHERE c.course_name = '高等数学'
  AND sc.score = (SELECT MAX(sc2.score) FROM scores sc2 WHERE sc2.course_id = sc.course_id);

-- 10
SELECT c.course_name FROM courses c LEFT JOIN scores sc ON c.course_id = sc.course_id
WHERE sc.course_id IS NULL;                             -- 离散数学

-- 11
SELECT t.name FROM teachers t LEFT JOIN courses c ON t.teacher_id = c.teacher_id
WHERE c.course_id IS NULL;                              -- 吴敏

-- 12
SELECT s.name, COUNT(*) AS cnt
FROM students s JOIN scores sc USING(student_id)
GROUP BY s.student_id, s.name HAVING cnt > 5;

-- 13
SELECT DISTINCT s.name FROM scores sc JOIN students s USING(student_id)
WHERE sc.score IS NULL;

-- 14
SELECT c.course_name, COUNT(sc.student_id) AS cnt
FROM courses c LEFT JOIN scores sc ON c.course_id = sc.course_id
GROUP BY c.course_id, c.course_name ORDER BY cnt DESC, c.course_id;

-- 15 (相关子查询;并列最高分会同时列出)
SELECT c.course_name, s.name, sc.score
FROM scores sc JOIN students s ON sc.student_id = s.student_id
JOIN courses c ON sc.course_id = c.course_id
WHERE sc.score = (SELECT MAX(sc2.score) FROM scores sc2 WHERE sc2.course_id = sc.course_id);

-- 16
SELECT s.name, sc.score
FROM scores sc JOIN students s ON sc.student_id = s.student_id
JOIN courses c ON sc.course_id = c.course_id
WHERE c.course_name = '数据库原理'
  AND sc.score > (SELECT AVG(sc2.score) FROM scores sc2
                  JOIN courses c2 ON sc2.course_id = c2.course_id
                  WHERE c2.course_name = '数据库原理');

-- 17 (双重否定:不存在"张伟的课里该生没选的")
SELECT s.name FROM students s
WHERE NOT EXISTS (
    SELECT 1 FROM courses c
    WHERE c.teacher_id = (SELECT teacher_id FROM teachers WHERE name = '张伟')
      AND NOT EXISTS (SELECT 1 FROM scores sc
                      WHERE sc.course_id = c.course_id AND sc.student_id = s.student_id)
);

-- 18 (不存在任何一条"缺考或不及格"的记录)
SELECT s.name FROM students s
WHERE NOT EXISTS (
    SELECT 1 FROM scores sc
    WHERE sc.student_id = s.student_id AND (sc.score IS NULL OR sc.score < 60)
);

-- 19
SELECT s.name, SUM(sc.score) AS total,
       RANK() OVER (ORDER BY SUM(sc.score) DESC) AS rk
FROM students s JOIN scores sc ON s.student_id = sc.student_id
WHERE sc.score IS NOT NULL
GROUP BY s.student_id, s.name ORDER BY total DESC LIMIT 5;

-- 20
SELECT name, birth_date, TIMESTAMPDIFF(YEAR, birth_date, CURDATE()) AS age
FROM students ORDER BY birth_date ASC, student_id LIMIT 5;
```
</details>

---

## 附:复习自查清单

| 知识点 | 会了吗? |
|---|---|
| 建表/改表/删表,常用数据类型与约束 | ☐ |
| INSERT 多行 / UPDATE / DELETE(先写 WHERE 的习惯) | ☐ |
| SELECT 子句书写顺序 vs 执行顺序 | ☐ |
| WHERE:IN、BETWEEN、LIKE、IS NULL、三值逻辑 | ☐ |
| DISTINCT、列别名 | ☐ |
| ORDER BY 多列、LIMIT/OFFSET | ☐ |
| COUNT/SUM/AVG/MAX/MIN 与 NULL 的关系 | ☐ |
| GROUP BY 规则、HAVING vs WHERE | ☐ |
| INNER/LEFT/RIGHT JOIN、自连接、USING/ON | ☐ |
| 标量/列/表子查询,相关子查询,EXISTS | ☐ |
| 字符串/数值/日期/CASE WHEN 常用函数 | ☐ |
| 视图的创建与更新限制 | ☐ |
| 索引类型、建索引原则、EXPLAIN | ☐ |
| 事务 ACID、COMMIT/ROLLBACK/SAVEPOINT、隔离级别 | ☐ |
| ROW_NUMBER/RANK/DENSE_RANK 的区别 | ☐ |

---

*提示:建议练习时使用 `mysql -u root -p` 交互输入密码;本机 root 密码较弱(123456),有条件的话练习完后用 `ALTER USER 'root'@'localhost' IDENTIFIED BY '新密码';` 改一下。*
